import { json, originAllowed, clearCookie } from "./_auth.mjs";
export async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "Metode tidak diizinkan." });
  if (!originAllowed(event)) return json(403, { error: "Permintaan ditolak." });
  return json(200, { ok: true }, { "Set-Cookie": clearCookie() });
}