import { json, originAllowed, passwordMatches, issueSession, cookieHeader } from "./_auth.mjs";

export async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "Metode tidak diizinkan." }, { Allow: "POST" });
  if (!originAllowed(event)) return json(403, { error: "Permintaan ditolak." });
  try {
    const body = JSON.parse(event.body || "{}");
    const username = String(body.username || "");
    const password = String(body.password || "");
    if (username.length > 80 || password.length > 200) return json(400, { error: "Input tidak valid." });
    const configuredUser = process.env.ADMIN_USERNAME;
    const okUser = configuredUser && username === configuredUser;
    const okPassword = await passwordMatches(password);
    if (!okUser || !okPassword) return json(401, { error: "Username atau password salah." });
    const token = issueSession(username);
    return json(200, { ok: true }, { "Set-Cookie": cookieHeader(token) });
  } catch (e) {
    return json(500, { error: "Konfigurasi server belum lengkap." });
  }
}