import { getStore } from "@netlify/blobs";
export async function handler(event) {
  if (event.httpMethod !== "GET") return { statusCode: 405, body: "Method Not Allowed" };
  try {
    const store = getStore({ name: "jb-store-products", consistency: "strong" });
    const products = await store.get("items", { type: "json" }) || [];
    return { statusCode: 200, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ products }) };
  } catch { return { statusCode: 200, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ products: [] }) }; }
}