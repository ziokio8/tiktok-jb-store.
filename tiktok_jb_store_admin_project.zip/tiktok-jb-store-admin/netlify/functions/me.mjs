import { json, verifySession } from "./_auth.mjs";
export async function handler(event) {
  if (event.httpMethod !== "GET") return json(405, { error: "Metode tidak diizinkan." });
  const session = verifySession(event);
  return session ? json(200, { authenticated: true, username: session.sub }) : json(401, { authenticated: false });
}