import { getStore } from "@netlify/blobs";
import { json, verifySession, originAllowed } from "./_auth.mjs";

const store = () => getStore({ name: "jb-store-products", consistency: "strong" });
const clean = (p) => ({
  id: String(p.id || crypto.randomUUID()),
  title: String(p.title || "").slice(0, 100),
  username: String(p.username || "").slice(0, 80),
  followers: String(p.followers || "").slice(0, 40),
  price: String(p.price || "").slice(0, 40),
  image: String(p.image || "").slice(0, 500),
  status: String(p.status || "Tersedia").slice(0, 30)
});
import crypto from "node:crypto";

export async function handler(event) {
  if (!verifySession(event)) return json(401, { error: "Silakan login kembali." });
  const db = store();
  if (event.httpMethod === "GET") {
    const products = await db.get("items", { type: "json" }) || [];
    return json(200, { products });
  }
  if (event.httpMethod !== "POST" || !originAllowed(event)) return json(403, { error: "Permintaan ditolak." });
  try {
    const body = JSON.parse(event.body || "{}");
    let products = await db.get("items", { type: "json" }) || [];
    if (body.action === "save") {
      const item = clean(body.product || {});
      if (!item.title || !item.price) return json(400, { error: "Nama produk dan harga wajib diisi." });
      const index = products.findIndex(p => p.id === item.id);
      if (index >= 0) products[index] = item; else products.unshift(item);
    } else if (body.action === "delete") {
      products = products.filter(p => p.id !== String(body.id));
    } else {
      return json(400, { error: "Aksi tidak dikenal." });
    }
    await db.setJSON("items", products);
    return json(200, { products });
  } catch {
    return json(400, { error: "Data tidak valid." });
  }
}