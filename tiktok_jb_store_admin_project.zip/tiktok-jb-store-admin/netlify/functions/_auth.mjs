import crypto from "node:crypto";
import bcrypt from "bcryptjs";

const COOKIE = "jb_admin_session";
const TTL = 8 * 60 * 60;

export function json(statusCode, data, extra = {}) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...extra
    },
    body: JSON.stringify(data)
  };
}

function b64url(value) {
  return Buffer.from(value).toString("base64url");
}
function signature(payload, secret) {
  return crypto.createHmac("sha256", secret).update(payload).digest("base64url");
}
function safeEqual(a, b) {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
export function cookieHeader(value, maxAge = TTL) {
  return `${COOKIE}=${value}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}
export function clearCookie() {
  return `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
}
export function originAllowed(event) {
  const origin = event.headers.origin;
  const host = event.headers.host;
  if (!origin || !host) return false;
  try { return new URL(origin).host === host; } catch { return false; }
}
export async function passwordMatches(password) {
  const hash = process.env.ADMIN_PASSWORD_HASH;
  if (!hash) throw new Error("ADMIN_PASSWORD_HASH belum diatur.");
  return bcrypt.compare(password, hash);
}
export function issueSession(username) {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.length < 32) throw new Error("ADMIN_SESSION_SECRET harus minimal 32 karakter.");
  const payload = b64url(JSON.stringify({ sub: username, exp: Math.floor(Date.now()/1000) + TTL }));
  return `${payload}.${signature(payload, secret)}`;
}
export function verifySession(event) {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.length < 32) return null;
  const raw = event.headers.cookie || "";
  const pair = raw.split(";").map(v => v.trim()).find(v => v.startsWith(`${COOKIE}=`));
  if (!pair) return null;
  const token = pair.slice(COOKIE.length + 1);
  const [payload, sig, extra] = token.split(".");
  if (!payload || !sig || extra) return null;
  if (!safeEqual(sig, signature(payload, secret))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (!data.sub || data.sub !== process.env.ADMIN_USERNAME || data.exp < Math.floor(Date.now()/1000)) return null;
    return data;
  } catch { return null; }
}
export function requirePost(event) {
  return event.httpMethod === "POST" && originAllowed(event);
}
