import bcrypt from "bcryptjs";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";

const rl = createInterface({ input, output });
const password = await rl.question("Masukkan password admin (input terlihat di terminal): ");
rl.close();
if (password.length < 10) {
  console.error("Password minimal 10 karakter.");
  process.exit(1);
}
console.log("\nSimpan nilai berikut sebagai environment variable ADMIN_PASSWORD_HASH di Netlify:\n");
console.log(await bcrypt.hash(password, 12));
